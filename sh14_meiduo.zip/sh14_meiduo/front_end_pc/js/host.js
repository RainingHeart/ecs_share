// 保存后端API服务器的地址
var host = 'http://api.meiduo.site:8000';