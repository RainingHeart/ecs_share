from django.apps import AppConfig


class UsersConfig(AppConfig):
    name = 'users'
    # name = 'meiduo_mall.apps.users'
