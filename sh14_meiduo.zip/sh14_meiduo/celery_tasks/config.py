# 设置中间人broker地址
broker_url = 'redis://172.16.179.139:6379/3'
